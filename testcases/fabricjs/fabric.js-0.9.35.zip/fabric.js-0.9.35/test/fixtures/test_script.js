(function(){
  // set global variable
  this.foo = 'bar';
})();