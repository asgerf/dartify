define(function() {
    Q.module('Sprite');
});
