define(function() {
    Q.module('WebGLBatch');
});
