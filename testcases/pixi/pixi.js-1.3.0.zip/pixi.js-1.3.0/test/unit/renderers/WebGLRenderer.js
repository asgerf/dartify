define(function() {
    Q.module('WebGLRenderer');
});
