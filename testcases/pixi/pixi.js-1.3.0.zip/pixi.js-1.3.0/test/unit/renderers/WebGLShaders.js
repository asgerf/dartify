define(function() {
    Q.module('WebGLShaders');
});
