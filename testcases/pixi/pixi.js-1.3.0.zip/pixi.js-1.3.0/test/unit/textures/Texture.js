define(function() {
    Q.module('Texture');
});
