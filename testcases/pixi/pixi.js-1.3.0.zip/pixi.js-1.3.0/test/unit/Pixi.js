define(function() {
    Q.module('Pixi');
});
