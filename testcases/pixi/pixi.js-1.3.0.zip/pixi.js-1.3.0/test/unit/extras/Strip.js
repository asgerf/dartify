define(function() {
    Q.module('Strip');
});
