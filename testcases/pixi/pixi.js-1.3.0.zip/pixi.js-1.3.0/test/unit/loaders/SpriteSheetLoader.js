define(function() {
    Q.module('SpriteSheetLoader');
});
