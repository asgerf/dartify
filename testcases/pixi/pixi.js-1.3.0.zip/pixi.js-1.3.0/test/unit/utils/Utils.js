define(function() {
    Q.module('Utils');
});
