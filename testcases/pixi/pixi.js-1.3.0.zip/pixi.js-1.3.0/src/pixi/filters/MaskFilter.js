/**
 * @author Mat Groves http://matgroves.com/ @Doormat23
 */



PIXI.MaskFilter = function(graphics)
{
	// the graphics data that will be used for filtering
	this.graphics;
}

