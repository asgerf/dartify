// The date and time format (%c), date format (%x) and time format (%X).
var d3_time_formatDateTime = {d_t_fmt},
    d3_time_formatDate = {d_fmt},
    d3_time_formatTime = {t_fmt};

// The weekday and month names.
var d3_time_days = {day},
    d3_time_dayAbbreviations = {abday},
    d3_time_months = {mon},
    d3_time_monthAbbreviations = {abmon};
